import logo from "./logo.svg";
import { useEffect } from "react";
import "./App.css";
import { worker } from "./__mock__/browser";

function App() {
  if (process.env.NODE_ENV === "development") {
    worker.start();
    /* 
      msw? -> 실제 db(x), 내가 만든 가상의 데이터, 개발 환경에서 개발 편의성
      production -> 실제 db와 소통하는 백엔드와 소통
    */
  }

  useEffect(() => {
    fetch("/api/todo")
      .then((res) => res.json())
      .then((result) => console.log(result));
  }, []);

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;
